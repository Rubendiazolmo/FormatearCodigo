import pyperclip

# Definición de funciones
def ExtraerSubOperaciones(Txt):
    # Inicializo variables
    TxtTrabajo = Txt
    Nivel = 0
    MaxNivel = 0
    NumEspTab = 4
    PosIniVar = 0
    Varibles = list()

    # Separo la operacion en lines
    OpLogicaT = Txt
    OpLogicaT = OpLogicaT.replace(")","\n)")
    OpLogicaT = OpLogicaT.replace("(","(\n    ")
    OpLogicaT = OpLogicaT.replace("AND","\nAND")
    OpLogicaT = OpLogicaT.replace("OR","\nOR ")
    OpLogicaT = OpLogicaT.splitlines()
    
    for i,Operacion in enumerate(OpLogicaT):

        OpLogicaT[i] = (NumEspTab * Nivel)*' ' + Operacion

        if "(" in Operacion:
            Nivel += 1
        
        if ")" in Operacion:
            Nivel -= 1
        
        if Nivel > MaxNivel:
            MaxNivel = Nivel

    # Extraigo variables de la operacion logica

    for i in (Txt.replace("(", "").replace(")", "").replace(" ", "\n").splitlines()):
        if not ((i == "OR") | (i == "AND") | (i == "NOT")):
            if not i in Varibles:
                Varibles.append(i)


    # Obtengo posición donde tienen que empezar las variables
    for Linea in OpLogicaT:
        for Variable in Varibles:
            if Variable in Linea:
                if (Linea.find(Variable)) > PosIniVar:
                    PosIniVar = (Linea.find(Variable))

    for i,Linea in enumerate(OpLogicaT):
        for Variable in Varibles:
            if Variable in Linea:
                if (Linea.find(Variable)) < PosIniVar:
                    OpLogicaT[i] = Linea.replace(Variable, " "*(PosIniVar-Linea.find(Variable)) + Variable)
                    continue

    out = OpLogicaT

    return out

    pass

def es_funcion(palabras_clave, instruccion):
    for i in palabras_clave:
        if i in instruccion:
            return True
            break

def FormatOpLog():

    pyperclip.waitForNewPaste()
    TxtEntrada = pyperclip.paste()

    # Variables de entrada

    TextATratar = TxtEntrada

    nots = TextATratar.count("NOT")
    espacio_not = 0

    if nots > 0:
        espacio_not = 4

    # Añado ; al final de la instrucción, en el caso de que no la tenga y compruebo que el string donde se pone la instrucción no esté vacia
    try:
        if (TextATratar[-1]) != ";":
            TextATratar += ";"
    except IndexError:
        print("La cadena de caracteres donde se introduce la instrucción está vacía")
        exit


    # Compuebo que los parentesis estén todos cerrados
    if TextATratar.count("(") != TextATratar.count(")"):
        print("Compruebe la operación lógica a formatear.")
        exit

    # Cuento los parentesis que tengo 
    nSubOpLogs = TextATratar.count("(")

    # Separo operación de la variable del resultado.
    VarAsignada = TextATratar.split(" := ")[0]
    OpLogica = TextATratar.split(" := ")[1]

    OpLogicaT = OpLogica

    # Extraigo SubOperaciones Logicas
    Operaciones = ExtraerSubOperaciones(OpLogicaT)

    Operaciones[0] = VarAsignada + " := " + Operaciones[0]


    for i, linea in enumerate(Operaciones):
        if (i) > 0:
            Operaciones[i] = (len(VarAsignada) + 4) * " " + Operaciones[i]

    # Uno todas las lineas para obtener la operación con el formato deseado

    res = "\r\n".join(Operaciones)
       
    pyperclip.copy(res)

def Tabular():

    salida = ""

    pyperclip.waitForNewPaste()
    contenido = pyperclip.paste()

    if contenido != salida:
                    
        caracter_asignacion = str(' := ') # Esto es un comentario
        caracter_comentario = str(' // ') # Comentarios
        contenido_con_comentarios = list()
        asignaciones_tabuladas = list()
        contenido_partido = list()
        contenido_sin_comentarios = list()
        contenido_tabulado_comentarios = ''
        lista_caracteres1 = list() 
        lista_caracteres2 = list()
        caracteres_1 = 0
        caracteres_2 = 0
        salida = ""
        aux = 0
        palabras_reservadas = ('IF', 'ELSE', 'FOR', 'WHILE', 'END_IF', 'END_FOR', 'END_WHILE')

        contenido = contenido.splitlines()

        for i in contenido:

            contenido_con_comentarios.append(i.partition(caracter_comentario))

        for i in contenido:

            contenido_sin_comentarios.append(i.partition(caracter_comentario)[0])

        for i in contenido_sin_comentarios:  

            contenido_partido.append(i.partition(caracter_asignacion))  

        for i in contenido_partido:  

            if i[1] != '':

                if (len(i[0]) > caracteres_1):
                    caracteres_1 = len(i[0])

            else:

                lista_caracteres1.append(caracteres_1)
                caracteres_1 = 0

        lista_caracteres1.append(caracteres_1)

        for i in contenido_partido:

            if i[1] != '':

                if len(i[2]) > caracteres_2:

                    caracteres_2 = len(i[2])

            else:

                lista_caracteres2.append(caracteres_2)
                caracteres_2 = 0

        lista_caracteres2.append(caracteres_2)

        for i in contenido_partido:

            if i[1] != '' or es_funcion(palabras_reservadas, i[0]):

                asignaciones_tabuladas.append(str(i[0]).ljust(lista_caracteres1[aux]) + str(i[1]).center(len(str(i[1]))+0) + (str(i[2]).lstrip()).rjust(lista_caracteres2[aux]))

            else:

                asignaciones_tabuladas.append(str(i[0]) + "\n")
                aux += 1

        for i in range(len(contenido_con_comentarios)):

            contenido_tabulado_comentarios = contenido_tabulado_comentarios + (asignaciones_tabuladas[i]+contenido_con_comentarios[i][1]+contenido_con_comentarios[i][2]) + "\n"

        '''---------------------------------------------------'''

        contenido = contenido_tabulado_comentarios.splitlines()

        contenido_partido = list()

        for index,i in enumerate(contenido):

            tmp = i.partition(caracter_comentario)
            
            if len(tmp[1]) > 0 and tmp[0] == '' :

                siguiente_linea = contenido[index+1]

                for j, letra in enumerate(siguiente_linea):
                    if letra != ' ':
                        break

                contenido_partido.append((j*' ' + tmp[1][1:len(tmp[1])-1] + ' ' + tmp[2], '', ''))
            else:
                contenido_partido.append(tmp)  

        for i in contenido_partido:

            if (len(i[0]) > caracteres_1):
                caracteres_1 = len(i[0])

        lista_caracteres1.append(caracteres_1)

        for i in contenido_partido:

            if len(i[2]) > caracteres_2:

                caracteres_2 = len(i[2])

        for index,i in enumerate(contenido_partido):

            if (i[1] != ''):

                if index != len(contenido_partido)-1:
                    salida = salida + (str(i[0]).ljust(caracteres_1) + str(i[1]).center(len(str(i[1]))+4) + (str(i[2]).lstrip()).ljust(caracteres_2) + "\r\n")
                else:
                    salida = salida + (str(i[0]).ljust(caracteres_1) + str(i[1]).center(len(str(i[1]))+4) + (str(i[2]).lstrip()).ljust(caracteres_2))

            else:

                if index < len(contenido_partido)-1:
                    salida = salida + str(i[0]) + "\r\n"
                else:
                    salida = salida + str(i[0])

                aux += 1
        
        pyperclip.copy(salida)