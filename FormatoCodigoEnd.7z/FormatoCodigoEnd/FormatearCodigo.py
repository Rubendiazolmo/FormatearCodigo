import pyperclip
import os
from Funciones import FormatOpLog, Tabular

salida = ''

def main():

    descripcion = ""

    print("Seleccione la acción que quiera realizar")
    accion = int(input("1: Tabular código\n2: Dar formato operación lógica\nAcción: "))
    print("Copie el texto a modificar")

    if accion == 1:
        Tabular()
        descripcion = "tabulado"
    
    if accion == 2:
        FormatOpLog()
        descripcion = "formateado"

    os.system("cls") # Limpia consola

    print(f'El texto {descripcion} ha sido copiado al clipboar')
    input()

if __name__ == "__main__":

    main()